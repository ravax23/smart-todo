console.log('Current selectedTaskList:', selectedTaskList);
