# SmartTodo

シンプルで使いやすいタスク管理アプリケーション

## 🌐 ライブデモ

**本番環境**: 
- CloudFront: https://d1yqrgdl6vrr4q.cloudfront.net
- AWS Amplify: https://main.d1d4qgmdk8rbkr.amplifyapp.com

## 機能

- Google認証によるログイン
- カテゴリ別タスク管理
- 日付別フィルタリング
- マイリスト機能
- タスクの優先度設定
- 完了タスクの表示/非表示切り替え
- Google Calendarとの同期（開発中）

## 最新の更新

- UI改善: マイリスト名の横にゴミ箱アイコンを表示
- フィルター表示の修正: フィルター選択時とマイリスト選択時の表示を明確に区別
- パッケージの更新: @mui/x-date-pickers を 8.5.0 にアップデート
- AWS展開: S3 + CloudFront による本番環境構築

## AWS インフラストラクチャ

### 構成
- **S3バケット**: `smarttodo-app-static-hosting`
- **CloudFront**: `E2E6NVYTYW4IE8`
- **ドメイン**: `d1yqrgdl6vrr4q.cloudfront.net`

### デプロイメント
```bash
# 自動デプロイ
./deploy.sh

# 手動デプロイ
npm run build
aws s3 sync build/ s3://smarttodo-app-static-hosting --delete
aws cloudfront create-invalidation --distribution-id E2E6NVYTYW4IE8 --paths "/*"
```

## セットアップ

### 前提条件

- Node.js 14.x以上
- npm 6.x以上
- Google Cloud Projectのアカウント

### インストール

1. リポジトリをクローン

```bash
git clone https://github.com/ravax23/todo-app.git
cd todo-app
```

2. 依存パッケージをインストール

```bash
npm install
```

3. 環境変数の設定

`.env.example`ファイルを`.env`にコピーし、必要な環境変数を設定します。

```bash
cp .env.example .env
```

`.env`ファイルを編集し、以下の変数を設定します：

- `REACT_APP_GOOGLE_CLIENT_ID`: Google Cloud ConsoleのOAuth 2.0クライアントID
- `REACT_APP_GOOGLE_API_KEY`: Google Cloud ConsoleのAPIキー（オプション）

### Google Cloud Projectの設定

1. [Google Cloud Console](https://console.cloud.google.com/)にアクセス
2. 新しいプロジェクトを作成
3. OAuth同意画面を設定
   - ユーザータイプ: 外部
   - アプリ名、ユーザーサポートメール、デベロッパーの連絡先情報を入力
   - スコープは`profile`と`email`を追加
4. 認証情報ページでOAuth 2.0クライアントIDを作成
   - アプリケーションタイプ: ウェブアプリケーション
   - 名前: Todo App
   - 承認済みのJavaScript生成元: `http://localhost:3000`（開発環境の場合）
   - 承認済みのリダイレクトURI: 不要
5. 作成されたクライアントIDを`.env`ファイルの`REACT_APP_GOOGLE_CLIENT_ID`に設定

### 開発サーバーの起動

```bash
npm start
```

アプリケーションは http://localhost:3000 で実行されます。

## 使い方

### タスク管理

- 新しいタスクを追加: 画面上部の入力フィールドにタスク名を入力し、Enterキーを押す
- タスクの完了: タスク左側のチェックボックスをクリック
- タスクの編集: タスクをクリックして詳細を編集
- タスクの削除: タスク右側のゴミ箱アイコンをクリック

### マイリスト

- 新しいマイリストを作成: 左サイドバーの「+」ボタンをクリック
- マイリストの選択: 左サイドバーのマイリスト名をクリック
- マイリストの削除: マイリスト選択時に右画面のマイリスト名横のゴミ箱アイコンをクリック

### フィルター

- 今日のタスク: 左サイドバーの「今日」をクリック
- 今週のタスク: 左サイドバーの「今週」をクリック
- 期限切れのタスク: 左サイドバーの「期限切れ」をクリック
- スター付きタスク: 左サイドバーの「スター付き」をクリック
- すべてのタスク: 左サイドバーの「すべて」をクリック

## 開発

### ブランチ戦略

- `main`: 本番環境用のブランチ
- `feature/*`: 新機能開発用のブランチ
- `bugfix/*`: バグ修正用のブランチ
- `archived/*`: 完了したブランチのアーカイブ

### コミットメッセージの形式

```
[タイプ]: [説明]

[詳細な説明（オプション）]
```

タイプ:
- `Feature`: 新機能
- `Fix`: バグ修正
- `Docs`: ドキュメントのみの変更
- `Style`: コードの意味に影響しない変更（フォーマットなど）
- `Refactor`: バグ修正や機能追加ではないコード変更
- `Test`: テストの追加・修正
- `Chore`: ビルドプロセスやツールの変更

## ライセンス

このプロジェクトはMITライセンスの下で公開されています。
